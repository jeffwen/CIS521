package com.aicontest.visualizer;

public interface IProgram {

	String[] getFiles();
	
}
