package com.aicontest.visualizer.js.dom;

public class TextMetrics
{
  public int width;

  public TextMetrics(int width)
  {
    this.width = width;
  }
}